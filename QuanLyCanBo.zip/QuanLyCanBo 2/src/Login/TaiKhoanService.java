package Login;

/**
 *
 * @author admin
 */
public interface TaiKhoanService {
    public TaiKhoan login(String tdn, String mk);
}

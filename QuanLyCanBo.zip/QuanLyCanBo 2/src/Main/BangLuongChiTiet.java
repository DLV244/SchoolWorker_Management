package Main;
abstract public class BangLuongChiTiet {
    protected int MaBangLuong;
    protected int MaCB;
    protected double LuongCung;
    protected double PhuCapThamNien;
    protected double PhuCapChucVu;
    protected double TongLuong;

    public void setPhuCapThamNien(double PhuCapThamNien) {
        this.PhuCapThamNien = PhuCapThamNien;
    }

    public void setPhuCapChucVu(double PhuCapChucVu) {
        this.PhuCapChucVu = PhuCapChucVu;
    }

    public void setTongLuong(double TongLuong) {
        this.TongLuong = TongLuong;
    }

    public double getPhuCapThamNien() {
        return PhuCapThamNien;
    }

    public double getPhuCapChucVu() {
        return PhuCapChucVu;
    }

    public double  getTongLuong() {
        return TongLuong;
    }
    protected String GhiChu;



    public BangLuongChiTiet(){}


    public BangLuongChiTiet(int MaBangLuong,int MaCB, int LuongCung,double PhuCapThamNien,double PhuCapChucVu,double TongLuong, String GhiChu){
        this.MaBangLuong = MaBangLuong;
        this.MaCB = MaCB;
        this.LuongCung = LuongCung;
        this.PhuCapChucVu = PhuCapChucVu;
        this.PhuCapThamNien = PhuCapThamNien;
        this.TongLuong = TongLuong;
        this.GhiChu = GhiChu;
    }

    public int getMaBangLuong() {
        return MaBangLuong;
    }

    public int getMaCB() {
        return MaCB;
    }

    public double getLuongCung() {
        return LuongCung;
    }

    public String getGhiChu() {
        return GhiChu;
    }

    public void setMaBangLuong(int MaBangLuong) {
        this.MaBangLuong = MaBangLuong;
    }

    public void setMaCB(int MaCB) {
        this.MaCB = MaCB;
    }

    public void setLuongCung(double LuongCung) {
        this.LuongCung = LuongCung;
    }
    
    
    public void setGhiChu(String GhiChu) {
        this.GhiChu = GhiChu;
    }
        
}



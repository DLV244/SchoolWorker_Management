package Main;
abstract public class BangLuong {
    protected int MaBangLuong;
    protected int Thang;
    protected int Nam;
    protected int LuongToiThieu;
    
    public BangLuong(){}
    
    public BangLuong(int MaBangLuong, int Thang, int Nam, int LuongToiThieu){
        this.MaBangLuong = MaBangLuong;
        this.LuongToiThieu = LuongToiThieu;
        this.Nam = Nam;
        this.Thang = Thang;
    }

    public int getMaBangLuong() {
        return MaBangLuong;
    }

    public int getThang() {
        return Thang;
    }

    public int getNam() {
        return Nam;
    }

    public int getLuongToiThieu() {
        return LuongToiThieu;
    }

    public void setMaBangLuong(int MaBangLuong) {
        this.MaBangLuong = MaBangLuong;
    }

    public void setThang(int Thang) {
        this.Thang = Thang;
    }

    public void setNam(int Nam) {
        this.Nam = Nam;
    }

    public void setLuongToiThieu(int LuongToiThieu) {
        this.LuongToiThieu = LuongToiThieu;
    }
    
    
}
